import java.util.Iterator;
import java.util.Random;

public class Algorithm {
	private Test test;
	private Inputs inputs;
	private Random rng;
	private Costs costs;
	private Solution BDS = null;
	private Solution BSS = null;
	private Solution newSol = null;
	private Outputs outputs = new Outputs();
	private RouteCache cache;

	Algorithm(Test test, Inputs inputs, Random rng, Costs costs) {
		this.test = test;
		this.inputs = inputs;
		this.rng = rng;
		this.costs = costs;
		cache = new RouteCache();
	}

	public Outputs solve() {
		long start = Time.systemTime();
		double elapsed = 0.0;
		Tree BSSList = new Tree(); // Tree set
		BDS = RandCWS.solve(test, inputs, costs, rng);
		BDS.localSearch(test, inputs, costs);
		BDS = cache.fastLS(BDS, test, inputs, costs, rng);
		BDS = ILS.perturb(BDS, test, inputs, costs, rng);
		BDS.localSearch(test, inputs, costs);
		elapsed = Time.calcElapsed(start, Time.systemTime());
		BDS.setElapsedTime(elapsed);
		BDS.MCS(false, test, inputs, costs);
		Solution baseSol = new Solution(BDS);
		while (baseSol.getRelDemand() <= test.getPDemand() || baseSol.getRelTime() <= test.getPTime()) {
			if(baseSol.getRelDemand() < test.getPDemand()){				
				double aux = Math.min(test.getSafetyStockC1() + 0.02, 0.50);
				test.setSafetyStockC1(aux);} 
			if(baseSol.getRelTime() < test.getPTime()){
				double aux = Math.min(test.getSafetyStockB() + 0.02, 0.50);
				test.setSafetyStockB(aux);} 
			baseSol = RandCWS.solve(test, inputs, costs, rng);
			baseSol.localSearch(test, inputs, costs);
			baseSol.MCS(false, test, inputs, costs);
			elapsed = Time.calcElapsed(start, Time.systemTime());
			if(elapsed > test.getMaxTime()){
				System.out.println("Feasible sol not found!");
				return null;}
		}
		System.out.println(baseSol.getRelDemand() + " -- " + baseSol.getRelTime());
		System.out.println("Expected Optimization cost: " + baseSol.getExpOptCost());
		BSS = new Solution(baseSol);
		StochSol aux = new StochSol(BSS, BSS.getExpOptCost());
		BSSList.addSolution(aux);
		System.out.println("START ILS");
		while (elapsed < test.getMaxTime()) {
			newSol = ILS.perturb(baseSol, test, inputs, costs, rng);
			newSol.localSearch(test, inputs, costs);
			elapsed = Time.calcElapsed(start, Time.systemTime());
			newSol.setElapsedTime(elapsed);
			if (newSol.getOptCost() < BDS.getOptCost()) {
				BDS = newSol;
			}
			if (newSol.getOptCost() < baseSol.getOptCost()) {
				// System.out.println("Better det");
				newSol.MCS(false, test, inputs, costs);
				//if (newSol.getRelDemand() >= BDS.getRelDemand() && newSol.getRelTime() >= BDS.getRelTime()) {
				if(newSol.getRelDemand() >= test.getPDemand() && newSol.getRelTime() >= test.getPTime()){
					double rpd = (newSol.getExpOptCost() - baseSol.getExpOptCost()) / baseSol.getExpOptCost() * 100;
					if (rpd <= 0) {
						System.out.println("Expected Optimization cost: " + newSol.getExpOptCost());
						baseSol = newSol;
						aux = new StochSol(newSol, newSol.getExpOptCost());
						BSSList.addSolution(aux);
					} else {
						// System.out.println("Optimization cost: " + newSol.getOptCost());
						double u = rng.nextDouble();
						if (u < Math.exp(-rpd)) {
							baseSol = newSol;
						}
					}
				}
			}
		}
		Iterator<StochSol> itr = BSSList.getTree().iterator();
		while (itr.hasNext()) {
			StochSol solInList = itr.next();
			Solution sol = solInList.getkey();
			sol.MCS(true, test, inputs, costs);
			solInList.setValue(sol.getExpOptCost());
		}
		BDS.MCS(true, test, inputs, costs);
		BDS.finalUpdate(costs, test);
		Solution stochSol = BSSList.getTree().first().getkey();
		int size = BSSList.getSize() - 1;
		itr = BSSList.getTree().iterator();
		itr.next();
		System.out.println(stochSol.getRelDemand() + " -- " + stochSol.getRelTime());
		while(stochSol.getRelDemand() <= test.getPDemand() || stochSol.getRelTime() <= test.getPTime()){
			if(size == 0){
				stochSol = BSSList.getTree().first().getkey();
				break;
			}
			stochSol = itr.next().getkey();
			size--;
			System.out.println(stochSol.getRelDemand() + " -- " + stochSol.getRelTime());
		}
		stochSol.finalUpdate(costs, test);
		if (BDS.getExpOptCost() < stochSol.getExpOptCost() && 
				BDS.getRelDemand() >= test.getPDemand() && BDS.getRelTime() >= test.getPTime()) {
			System.out.println("DET BETTER THAN STOCH");
			stochSol = BDS;
		} 
		for(int i = 0; i < 30; i++){
			Solution auxStochSol = new Solution(stochSol);
			test.setSafetyStockC2(test.getSafetyStockC2() - 0.02);
			auxStochSol.MCS(true, test, inputs, costs);
			if(auxStochSol.getExpOptCost() < stochSol.getExpOptCost() && 
					auxStochSol.getRelDemand() >= test.getPDemand() && auxStochSol.getRelTime() >= test.getPTime()){
				stochSol = auxStochSol;
				System.out.println(stochSol.getRelDemand() + " -- " + stochSol.getRelTime());
			} else {
				test.setSafetyStockC2(test.getSafetyStockC2() + 0.02);
				break;
			}
		}
		BDS.MCS(true, test, inputs, costs); //hemos cambiado el SSC2
		outputs.setOBSol(BDS);
		outputs.setOBStochSol(stochSol);		
		return outputs;
	}

	public Outputs detSolve() {
		long start = Time.systemTime();
		double elapsed = 0.0;
		Solution baseSol = new Solution();
		System.out.println("RandCWS");
		baseSol = RandCWS.solve(test, inputs, costs, rng);
		System.out.println("Optimization cost: " + baseSol.getOptCost());
		System.out.println("LS");
		baseSol.localSearch(test, inputs, costs);
		System.out.println("Optimization cost: " + baseSol.getOptCost());
		System.out.println("Cache - fast LS");
		baseSol = cache.fastLS(baseSol, test, inputs, costs, rng);
		System.out.println("Optimization cost: " + baseSol.getOptCost());
		baseSol = ILS.perturb(baseSol, test, inputs, costs, rng);
		System.out.println("Optimization cost: " + baseSol.getOptCost());
		baseSol.localSearch(test, inputs, costs);
		System.out.println("Optimization cost: " + baseSol.getOptCost());
		elapsed = Time.calcElapsed(start, Time.systemTime());
		baseSol.setElapsedTime(elapsed);
		Solution bestSol = new Solution(baseSol);
		System.out.println("START ILS");
		while (elapsed < test.getMaxTime()) {
			newSol = ILS.perturb(baseSol, test, inputs, costs, rng);
			newSol.localSearch(test, inputs, costs);
			elapsed = Time.calcElapsed(start, Time.systemTime());
			newSol.setElapsedTime(elapsed);
			double rpd = (newSol.getOptCost() - baseSol.getOptCost())
					/ baseSol.getOptCost() * 100;
			if (rpd <= 0) {
				baseSol = newSol;
				bestSol = newSol;
			} else {
				double u = rng.nextDouble();
				if (u < Math.exp(-rpd)) {
					baseSol = newSol;
				}
			}
		}
		System.out.println("END ILS");
		bestSol.MCS(true, test, inputs, costs);
		bestSol.finalUpdate(costs, test);
		outputs.setOBSol(bestSol);
		outputs.setOBStochSol(bestSol);
		return outputs;
	}
}